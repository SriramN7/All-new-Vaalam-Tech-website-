import { Handshake, Globe, Shield, Zap } from 'lucide-react';

export default function Partners() {
  const benefits = [
    {
      icon: Handshake,
      title: 'Strategic Partnerships',
      description: 'Building long-term relationships for mutual success'
    },
    {
      icon: Globe,
      title: 'Global Reach',
      description: 'Expanding your business across international markets'
    },
    {
      icon: Shield,
      title: 'Trusted Network',
      description: 'Reliable partners with proven track records'
    },
    {
      icon: Zap,
      title: 'Fast Deployment',
      description: 'Quick implementation and seamless coordination'
    }
  ];

  return (
    <section id="partners" className="py-20 bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-2xl transform -rotate-3"></div>
              <img
                src="https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Partnership"
                className="relative rounded-2xl shadow-2xl w-full h-[500px] object-cover"
              />
              <div className="absolute top-6 right-6 bg-white rounded-xl shadow-xl p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-neon-orange to-orange-500 rounded-full flex items-center justify-center">
                    <Handshake className="w-5 h-5 text-white" />
                  </div>
                  <div className="font-bold text-gray-900">Trusted Partners</div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Our Partners
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              ACM Health Technologies (ACMHT), is a strategic partner providing sales & onsite
              co-ordination services for VTS. Together, we deliver comprehensive solutions
              that combine technical excellence with industry expertise.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => {
                const Icon = benefit.icon;
                return (
                  <div
                    key={index}
                    className="group p-6 rounded-xl bg-white shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-neon-orange to-orange-500 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">
                      {benefit.title}
                    </h3>
                    <p className="text-gray-600 text-sm">
                      {benefit.description}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="mt-8 p-6 bg-gradient-to-r from-neon-orange to-orange-500 rounded-xl text-white">
              <h3 className="text-xl font-bold mb-2">Join Our Partner Network</h3>
              <p className="mb-4 opacity-90">
                Interested in becoming a partner? Let's explore opportunities together.
              </p>
              <a
                href="#contact"
                className="inline-block bg-white text-neon-orange px-6 py-3 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                Contact Us
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
