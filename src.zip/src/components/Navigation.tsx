import { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const services = [
    { name: 'ERP Testing', href: '#services' },
    { name: 'Test Automation', href: '#services' },
    { name: 'Custom Application Testing', href: '#services' },
    { name: 'Test Maturity Assessment', href: '#services' },
    { name: 'Performance Testing', href: '#services' },
  ];

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-lg py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <a href="#home" className="flex items-center space-x-3 group">
            <div className="w-12 h-12 bg-gradient-to-br from-neon-orange to-orange-500 rounded-lg flex items-center justify-center transform group-hover:scale-110 transition-transform duration-300">
              <span className="text-white font-bold text-xl">VTS</span>
            </div>
            <span className={`font-bold text-lg transition-colors duration-300 ${
              isScrolled ? 'text-gray-900' : 'text-white'
            }`}>
              Vaalam Technology Services
            </span>
          </a>

          <div className="hidden lg:flex items-center space-x-8">
            <a
              href="#home"
              className={`font-medium transition-all duration-300 hover:scale-105 ${
                isScrolled ? 'text-gray-700 hover:text-neon-orange' : 'text-white hover:text-orange-300'
              }`}
            >
              Home
            </a>

            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown(true)}
              onMouseLeave={() => setActiveDropdown(false)}
            >
              <button
                className={`flex items-center space-x-1 font-medium transition-all duration-300 hover:scale-105 ${
                  isScrolled ? 'text-gray-700 hover:text-neon-orange' : 'text-white hover:text-orange-300'
                }`}
              >
                <span>Services</span>
                <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${activeDropdown ? 'rotate-180' : ''}`} />
              </button>

              {activeDropdown && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-xl py-2 transform opacity-100 scale-100 transition-all duration-200">
                  {services.map((service, index) => (
                    <a
                      key={index}
                      href={service.href}
                      className="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-neon-orange transition-colors duration-200"
                    >
                      {service.name}
                    </a>
                  ))}
                </div>
              )}
            </div>

            <a
              href="#about"
              className={`font-medium transition-all duration-300 hover:scale-105 ${
                isScrolled ? 'text-gray-700 hover:text-neon-orange' : 'text-white hover:text-orange-300'
              }`}
            >
              About
            </a>
            <a
              href="#partners"
              className={`font-medium transition-all duration-300 hover:scale-105 ${
                isScrolled ? 'text-gray-700 hover:text-neon-orange' : 'text-white hover:text-orange-300'
              }`}
            >
              Our Partners
            </a>
            <a
              href="#contact"
              className="bg-gradient-to-r from-neon-orange to-orange-500 text-white px-6 py-2 rounded-full font-medium hover:shadow-lg transform hover:scale-105 transition-all duration-300"
            >
              Contact Us
            </a>
          </div>

          <button
            className={`lg:hidden p-2 rounded-lg transition-colors duration-300 ${
              isScrolled ? 'text-gray-900 hover:bg-gray-100' : 'text-white hover:bg-white/10'
            }`}
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isOpen && (
          <div className="lg:hidden mt-4 pb-4 bg-white rounded-lg shadow-xl">
            <div className="flex flex-col space-y-2 px-4 py-2">
              <a href="#home" className="py-2 text-gray-700 hover:text-neon-orange transition-colors duration-200">
                Home
              </a>
              <div className="py-2">
                <button
                  onClick={() => setActiveDropdown(!activeDropdown)}
                  className="flex items-center justify-between w-full text-gray-700 hover:text-neon-orange transition-colors duration-200"
                >
                  <span>Services</span>
                  <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${activeDropdown ? 'rotate-180' : ''}`} />
                </button>
                {activeDropdown && (
                  <div className="mt-2 pl-4 space-y-2">
                    {services.map((service, index) => (
                      <a
                        key={index}
                        href={service.href}
                        className="block py-2 text-sm text-gray-600 hover:text-neon-orange transition-colors duration-200"
                      >
                        {service.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>
              <a href="#about" className="py-2 text-gray-700 hover:text-neon-orange transition-colors duration-200">
                About
              </a>
              <a href="#partners" className="py-2 text-gray-700 hover:text-neon-orange transition-colors duration-200">
                Our Partners
              </a>
              <a href="#contact" className="py-2 text-gray-700 hover:text-neon-orange transition-colors duration-200">
                Contact Us
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
