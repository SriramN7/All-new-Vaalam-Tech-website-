import { Boxes, Bot, FlaskConical, CheckSquare, Gauge } from 'lucide-react';
import { useState } from 'react';

const services = [
  {
    icon: Boxes,
    title: 'ERP Testing',
    description: 'Maximize benefits with affordable, intuitive & innovative ERP QA solutions',
    image: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: Bot,
    title: 'Test Automation',
    description: 'Reduction in cost, improved test coverage & easy to maintain script less automation frameworks.',
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-purple-500 to-pink-500'
  },
  {
    icon: FlaskConical,
    title: 'Custom Application Testing',
    description: 'Custom strategies for improved quality, reduced time to market and cost.',
    image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-green-500 to-emerald-500'
  },
  {
    icon: CheckSquare,
    title: 'Test Maturity Assessment',
    description: 'Audit, Assess, Advise & Apply best QA practices.',
    image: 'https://images.pexels.com/photos/3184325/pexels-photo-3184325.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-orange-500 to-red-500'
  },
  {
    icon: Gauge,
    title: 'Performance Testing',
    description: 'Performance Testing is a process by which a product/software is tested to determine and establish its current performance and ability to function to specification, monitoring throughput and response times.',
    image: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-indigo-500 to-blue-500'
  }
];

export default function Services() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section id="services" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive solutions tailored to your business needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="group relative bg-white rounded-2xl shadow-lg overflow-hidden transform transition-all duration-500 hover:scale-105 hover:shadow-2xl cursor-pointer"
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className={`w-full h-full object-cover transition-transform duration-700 ${
                      hoveredIndex === index ? 'scale-110' : 'scale-100'
                    }`}
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${service.color} opacity-60 transition-opacity duration-300 ${
                    hoveredIndex === index ? 'opacity-80' : 'opacity-60'
                  }`} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className={`bg-white/20 backdrop-blur-sm p-4 rounded-full transform transition-all duration-500 ${
                      hoveredIndex === index ? 'scale-110 rotate-12' : 'scale-100 rotate-0'
                    }`}>
                      <Icon className="w-12 h-12 text-white" />
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-neon-orange transition-colors duration-300">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {service.description}
                  </p>
                </div>

                <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${service.color} transform origin-left transition-transform duration-500 ${
                  hoveredIndex === index ? 'scale-x-100' : 'scale-x-0'
                }`} />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
