import { Lightbulb, Handshake, Clock, Rocket, Shield, TrendingUp } from 'lucide-react';

export default function WhyChoose() {
  const features = [
    {
      icon: Lightbulb,
      title: 'Innovation First',
      description: 'We stay ahead of industry trends to provide cutting-edge solutions.',
      color: 'from-yellow-500 to-orange-500'
    },
    {
      icon: Handshake,
      title: 'Partnership Approach',
      description: 'We work closely with you to understand your unique challenges and goals.',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Clock,
      title: 'Timely Delivery',
      description: 'We ensure projects are completed on time and within budget.',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Shield,
      title: 'Quality Assurance',
      description: 'Rigorous testing and quality control processes ensure excellence.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: TrendingUp,
      title: 'Proven Results',
      description: 'Track record of delivering measurable business outcomes.',
      color: 'from-red-500 to-orange-500'
    },
    {
      icon: Rocket,
      title: 'Scalable Solutions',
      description: 'Build solutions that grow with your business needs.',
      color: 'from-indigo-500 to-blue-500'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl transform rotate-3"></div>
              <img
                src="https://images.pexels.com/photos/3184639/pexels-photo-3184639.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Innovation"
                className="relative rounded-2xl shadow-2xl w-full h-[600px] object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-neon-orange mb-1">98%</div>
                  <div className="text-sm text-gray-600">Client Satisfaction</div>
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Why Choose Vaalam?
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              We combine technical expertise with business acumen to deliver solutions
              that drive real results. Here's what sets us apart:
            </p>

            <div className="space-y-4">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={index}
                    className="group flex items-start space-x-4 p-5 rounded-xl bg-gray-50 hover:bg-white hover:shadow-lg transition-all duration-300"
                  >
                    <div className="flex-shrink-0">
                      <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-neon-orange transition-colors duration-300">
                        {feature.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
