import { CheckCircle, Target, Users, Award } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: Target,
      text: 'Optimal Solution Design - using technology, expertise, innovation & best practices. Time tested implementation strategy – solutions guaranteeing business value'
    },
    {
      icon: Users,
      text: 'Industry expertise and insights'
    },
    {
      icon: Award,
      text: 'Customized solutions for your needs'
    }
  ];

  const stats = [
    { value: '15+', label: 'Years Experience' },
    { value: '200+', label: 'Projects Completed' },
    { value: '98%', label: 'Client Satisfaction' },
    { value: '50+', label: 'Team Members' }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              About Vaalam
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              The founding leaders of VTS Technologies are a group of individuals
              who have had long and distinguished careers of providing strategic leadership
              and handling executive management positions within the organizations they served earlier.
              Their keen sense of values, ethics and principles with the confidence of their
              experience has motivated them to launch out to set up this enterprise.
            </p>

            <div className="space-y-4 mb-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={index}
                    className="flex items-start space-x-4 p-4 rounded-lg hover:bg-blue-50 transition-colors duration-300 group"
                  >
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-neon-orange to-orange-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <p className="text-gray-700 leading-relaxed flex-1">
                      {feature.text}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div
                  key={index}
                  className="text-center p-4 rounded-lg bg-gradient-to-br from-blue-50 to-cyan-50 hover:shadow-lg transition-shadow duration-300"
                >
                  <div className="text-3xl font-bold text-neon-orange mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl transform rotate-3"></div>
              <img
                src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Team collaboration"
                className="relative rounded-2xl shadow-2xl w-full h-[500px] object-cover"
              />
              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-xl p-6 max-w-xs">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">Trusted Partner</div>
                    <div className="text-sm text-gray-600">Since 2009</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
